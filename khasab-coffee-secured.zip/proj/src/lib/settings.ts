import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";

export type BankAccount = {
  bank: string;
  number: string;
  holder: string;
  logo_type?: string;
  custom_logo_url?: string;
};

export const defaultBankAccounts: BankAccount[] = [
  { bank: "بنك الكريمي", number: "1234567890", holder: "محمصة خصب للقهوة", logo_type: "kuraimi" },
  { bank: "بنك القطيبي", number: "9876543210", holder: "محمصة خصب للقهوة", logo_type: "qutaibi" },
  { bank: "ون كاش", number: "777000000", holder: "محمصة خصب", logo_type: "onecash" },
  { bank: "محفظة جيب", number: "733111222", holder: "محمصة خصب", logo_type: "jeeb" },
];

export const defaultPickupAddress = "الحجاز الجديد محل أضواء الدور الأول - عدن";
export const defaultWhatsAppNumber = "967777000000";
export const defaultStoreName = "محمصة خصب";
export const defaultAdenDeliveryFee = "1,000 - 5,000 ر.ي";
export const defaultAdenDeliveryFeeSar = "3 - 12 ر.س";
export const defaultPickupFee = "مجاناً";
export const defaultPickupFeeSar = "مجاناً";
export const defaultOtherDeliveryFee = "2,000 - 5,000 ر.ي";
export const defaultOtherDeliveryFeeSar = "5 - 12 ر.س";

export type StoreSettings = {
  id?: string;
  store_name?: string;
  logo_url?: string;
  announcement_text: string;
  announcement_enabled: boolean;
  whatsapp_number: string;
  pickup_address: string;
  aden_delivery_fee: string;
  aden_delivery_fee_sar?: string;
  pickup_delivery_fee: string;
  pickup_delivery_fee_sar?: string;
  other_delivery_fee: string;
  other_delivery_fee_sar?: string;
  bank_accounts: BankAccount[];
};

export function parseStoreSettings(row: any): StoreSettings {
  if (!row) {
    return {
      store_name: defaultStoreName,
      logo_url: "",
      announcement_text: "توصيل مجاني عند الطلب بـ +100 ريال، تحميص أسبوعي، أجود أنواع القهوة المختصة",
      announcement_enabled: true,
      whatsapp_number: defaultWhatsAppNumber,
      pickup_address: defaultPickupAddress,
      aden_delivery_fee: defaultAdenDeliveryFee,
      aden_delivery_fee_sar: defaultAdenDeliveryFeeSar,
      pickup_delivery_fee: defaultPickupFee,
      pickup_delivery_fee_sar: defaultPickupFeeSar,
      other_delivery_fee: defaultOtherDeliveryFee,
      other_delivery_fee_sar: defaultOtherDeliveryFeeSar,
      bank_accounts: defaultBankAccounts,
    };
  }

  // Check if extra settings are stored inside hero_banners JSON or direct columns
  let extra: any = {};
  if (row.hero_banners) {
    if (Array.isArray(row.hero_banners) && row.hero_banners[0] && typeof row.hero_banners[0] === "object") {
      extra = row.hero_banners[0];
    } else if (typeof row.hero_banners === "object" && !Array.isArray(row.hero_banners)) {
      extra = row.hero_banners;
    }
  }

  let bankAccounts = row.bank_accounts || extra.bank_accounts;
  if (typeof bankAccounts === "string") {
    try {
      bankAccounts = JSON.parse(bankAccounts);
    } catch {
      bankAccounts = defaultBankAccounts;
    }
  }
  if (!Array.isArray(bankAccounts) || bankAccounts.length === 0) {
    bankAccounts = defaultBankAccounts;
  }

  return {
    id: row.id,
    store_name: row.store_name || extra.store_name || defaultStoreName,
    logo_url: row.logo_url || extra.logo_url || "",
    announcement_text: row.announcement_text ?? "توصيل مجاني عند الطلب بـ +100 ريال، تحميص أسبوعي، أجود أنواع القهوة المختصة",
    announcement_enabled: row.announcement_enabled ?? true,
    whatsapp_number: row.whatsapp_number || extra.whatsapp_number || defaultWhatsAppNumber,
    pickup_address: row.pickup_address || extra.pickup_address || defaultPickupAddress,
    aden_delivery_fee: row.aden_delivery_fee || extra.aden_delivery_fee || defaultAdenDeliveryFee,
    aden_delivery_fee_sar: row.aden_delivery_fee_sar || extra.aden_delivery_fee_sar || defaultAdenDeliveryFeeSar,
    pickup_delivery_fee: row.pickup_delivery_fee || extra.pickup_delivery_fee || defaultPickupFee,
    pickup_delivery_fee_sar: row.pickup_delivery_fee_sar || extra.pickup_delivery_fee_sar || defaultPickupFeeSar,
    other_delivery_fee: row.other_delivery_fee || extra.other_delivery_fee || defaultOtherDeliveryFee,
    other_delivery_fee_sar: row.other_delivery_fee_sar || extra.other_delivery_fee_sar || defaultOtherDeliveryFeeSar,
    bank_accounts: bankAccounts,
  };
}

export function useLiveStoreSettings() {
  const [settings, setSettings] = useState<StoreSettings>({
    store_name: defaultStoreName,
    logo_url: "",
    announcement_text: "توصيل مجاني عند الطلب بـ +100 ريال، تحميص أسبوعي، أجود أنواع القهوة المختصة",
    announcement_enabled: true,
    whatsapp_number: defaultWhatsAppNumber,
    pickup_address: defaultPickupAddress,
    aden_delivery_fee: defaultAdenDeliveryFee,
    aden_delivery_fee_sar: defaultAdenDeliveryFeeSar,
    pickup_delivery_fee: defaultPickupFee,
    pickup_delivery_fee_sar: defaultPickupFeeSar,
    other_delivery_fee: defaultOtherDeliveryFee,
    other_delivery_fee_sar: defaultOtherDeliveryFeeSar,
    bank_accounts: defaultBankAccounts,
  });
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try {
      const { data, error } = await supabase
        .from("store_settings")
        .select("*")
        .order("updated_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) {
        console.warn("Could not fetch store_settings:", error);
      }
      if (data) {
        setSettings(parseStoreSettings(data));
      }
    } catch (err) {
      console.error("useLiveStoreSettings error:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const chId = `settings-live-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const channel = supabase
      .channel(chId)
      .on("postgres_changes", { event: "*", schema: "public", table: "store_settings" }, (payload) => {
        console.log("Store settings updated via Realtime:", payload);
        load();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  return { settings, loading, reload: load };
}
